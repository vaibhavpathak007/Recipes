import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-starter',
  templateUrl: './recipe-starter.component.html',
  styleUrls: ['./recipe-starter.component.css']
})
export class RecipeStarterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
